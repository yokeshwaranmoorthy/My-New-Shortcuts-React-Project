
require("./NewShortcutsApp.module.css");
const styles = {
  wrapper: 'wrapper_84b958fa',
  banner: 'banner_84b958fa',
  bannerSubtitle: 'bannerSubtitle_84b958fa',
  bannerTitle: 'bannerTitle_84b958fa',
  tabBar: 'tabBar_84b958fa',
  tabs: 'tabs_84b958fa',
  tab: 'tab_84b958fa',
  activeTab: 'activeTab_84b958fa',
  moreIcon: 'moreIcon_84b958fa',
  content: 'content_84b958fa',
  topRow: 'topRow_84b958fa',
  greeting: 'greeting_84b958fa',
  greetingName: 'greetingName_84b958fa',
  greetingSub: 'greetingSub_84b958fa',
  stats: 'stats_84b958fa',
  statBox: 'statBox_84b958fa',
  activeStatBox: 'activeStatBox_84b958fa',
  statIcon: 'statIcon_84b958fa',
  statLabel: 'statLabel_84b958fa',
  statCount: 'statCount_84b958fa',
  cardsGrid: 'cardsGrid_84b958fa',
  card: 'card_84b958fa',
  cardTitle: 'cardTitle_84b958fa',
  ticketLink: 'ticketLink_84b958fa',
  cardRequestor: 'cardRequestor_84b958fa',
  mailIcon: 'mailIcon_84b958fa',
  cardCategory: 'cardCategory_84b958fa',
  cardFooter: 'cardFooter_84b958fa',
  redirectIcon: 'redirectIcon_84b958fa',
  navigateRow: 'navigateRow_84b958fa',
  navigateBtn: 'navigateBtn_84b958fa'
};

export default styles;
