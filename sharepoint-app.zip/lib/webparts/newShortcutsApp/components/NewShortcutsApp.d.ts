import * as React from "react";
import type { INewShortcutsAppProps } from "./INewShortcutsAppProps";
declare const NewShortcutsApp: React.FC<INewShortcutsAppProps>;
export default NewShortcutsApp;
//# sourceMappingURL=NewShortcutsApp.d.ts.map