export interface INewShortcutsAppProps {
    description: string;
    isDarkTheme: boolean;
    environmentMessage: string;
    hasTeamsContext: boolean;
    userDisplayName: string;
    userEmail: string;
}
export interface IShortcutItem {
    id: string;
    ticketNumber: string;
    description: string;
    requestor: string;
    category: string;
    status: string;
    url: string;
}
export interface IStatusCount {
    label: string;
    count: number;
}
export interface ITabData {
    label: string;
    statusCounts: IStatusCount[];
    navigateLabel: string;
    navigateUrl: string;
    items: IShortcutItem[];
}
//# sourceMappingURL=INewShortcutsAppProps.d.ts.map