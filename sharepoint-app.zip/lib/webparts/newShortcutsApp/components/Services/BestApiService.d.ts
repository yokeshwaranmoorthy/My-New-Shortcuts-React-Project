import { IShortcutItem, IStatusCount } from "../INewShortcutsAppProps";
export interface IBestTabResult {
    items: IShortcutItem[];
    statusCounts: IStatusCount[];
}
export declare function fetchBestTabData(userEmail: string): Promise<IBestTabResult>;
//# sourceMappingURL=BestApiService.d.ts.map